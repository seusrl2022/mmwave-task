import rospy
import time
from package_ti_iwr6843_dca1000_raw.msg import Frame
from steaming import adcCapThread




rospy.init_node('vayyar_element')
rospy.loginfo('helloword')
publisher = rospy.Publisher('raw_data', Frame, queue_size=50)

a = adcCapThread(1,"adc")
a.start()
counter = 0

while True:
    readItem,itemNum,lostPacketFlag=a.getFrame()
    if itemNum>0:
        # perpare message
        frame = Frame()
        frame.frame_id = str(counter)
        frame.stamp = rospy.Time.from_sec(time.time())
        frame.raw_data = readItem.tobytes()
        # publish
        publisher.publish(frame)
        counter += 1
        
    elif itemNum==-1:
        print(readItem)
    elif itemNum==-2:       
        time.sleep(0.04)
        
